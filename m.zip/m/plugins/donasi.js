let handler = async (m, { conn, usedPrefix: _p, __dirname, args }) => {
    let teks = `
︵‿︵‿︵‿︵ *DONASI BOT* ︵‿︵‿︵‿︵
┌─「 Donasi • Pulsa 」
│ • *Three:* [ 089512504270 ] 
❏────

┌─「 Donasi • Non Pulsa 」
│ • *Dana:* [ 089513902464 ]
│ • *Saweria:* [ saweria.co/ ]
❏────

*ʙᴀᴄᴋ ᴛᴏ ᴀʟʟ ᴍᴇɴᴜ*: .?
*ᴘɪɴɢ*: .ping
*ᴄʀᴇᴀᴛᴏʀ*: .creator
︵‿︵‿︵‿︵︵‿︵‿︵‿︵︵‿︵‿︵‿
Created by Devin
`

    let you = flaaa.getRandom()

    await conn.sendFile(m.chat, you + 'Donasi', 'donasi.jpg', m); 
};

handler.help = ['donasi'];
handler.tags = ['info'];
handler.command = /^dona(te|si)$/i;

export default handler;
